"""CS330 Spring 2019: Quiz 2 (take home)."""

import unittest
import shelf
import book

#Nicole R's code

# Steps to consider when writing any unit test:
# 1) Create an instance of the object whose behavior you want to test.
# 2) Ensure that the instance is initialized appropriately to exhibit the behavior need to meet the test objective.
# 3) Use the TestCase methods (self.assertXXXXX()) to show the test objective is met.
# 4) Verify object state before and after (where needed) to show that test actions affect the object's state.
# 5) Run your test class the same way you'd run any Python program.

# PyUnit Docs: https://docs.python.org/3/library/unittest.html


class TestShelf(unittest.TestCase):
    """Tests Shelf behavior."""

    def setUp(self):
        """Use or delete this method."""
        little_women = book.Book("Little Women", ("Louisa", "May", "Alcott"))
        little_women.SetPages(306)
        little_women.SetCoverType(book.CoverType.HARDCOVER)
        return little_women
        pass

    # Write unit tests for these Shelf class methods and behaviors:

    def test_AddBook(self):
        """Tests that a book is successfully added to a shelf."""
        shelf_one = shelf.Shelf()
        original = shelf_one.GetBookCount()
        little_women = self.setUp()
        shelf_one.AddBook(little_women)
        self.assertEqual(original + 1,shelf_one.GetBookCount())
        pass

    def test_RemoveBook(self):
        """Tests that a book is successfully removed from a shelf."""
        shelf_one = shelf.Shelf()
        little_women = self.setUp()
        shelf_one.AddBook(little_women)
        original_num_books = shelf_one.GetBookCount()
        shelf_one.RemoveBook("Little Women")
        self.assertEqual(shelf_one.GetBookCount(),original_num_books - 1)
        pass

    def test_AddBook_reduces_shelf_capacity(self):
        """Tests that shelf capacity is reduced after adding a book."""
        shelf_one = shelf.Shelf()
        original_num_books = shelf_one.GetBookCount()
        original_cap = shelf_one.GetAvailableCapacity()
        little_women = self.setUp()
        shelf_one.AddBook(little_women)
        self.assertEqual(original_num_books + 1, shelf_one.GetBookCount())
        self.assertLess(shelf_one.GetAvailableCapacity(), original_cap)
        pass

    def test_RemoveBook_increases_shelf_capacity(self):
        """Tests that shelf capacity is increased after removing a book."""
        shelf_one = shelf.Shelf()
        little_women = self.setUp()
        shelf_one.AddBook(little_women)
        original_cap = shelf_one.GetAvailableCapacity()
        shelf_one.RemoveBook("Little Women")
        self.assertGreater(shelf_one.GetAvailableCapacity(), original_cap)
        pass

    # Extra Credit
    def test_shelf_space_exhausted(self):
        """Tests that an exception is raised when adding a book to a shelf with insufficient space."""
        shelf_one = shelf.Shelf()
        shelf_one._ReduceCapacity(72)
        little_women = self.setUp()

        # Example uses a 'with' as a wrapper to catch the exception.
        with self.assertRaises(RuntimeError):
            shelf_one.AddBook(little_women)
        pass

if __name__ == '__main__':
    unittest.main()